package com.om.dao;

import com.om.model.Log;

public interface ILogDAO {
	public void save(Log transientInstance);
}
