package com.om.service;

import java.util.List;
import java.util.Set;

import com.om.model.Purchase;

public interface  IPurchaseService {
	Set<Purchase> loadPurchase();
}
