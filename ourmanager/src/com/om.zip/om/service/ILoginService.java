package com.om.service;

import com.om.model.User;

public interface ILoginService {
	public boolean execute(User user) ;
}
